<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center">2020 All rights reserved, Instrument House. Developed By - <a href="#"> Instrument</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>